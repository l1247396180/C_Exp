#include<iostream>
using namespace std;
int main()
{
	cout<<"\"HELLO BJTU\""<<endl;
	cout<<"\"HELLO BJTU\\n\""<<endl;
	system("pause");
	return 0;
}