#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	int a=30;
	double x=0.3;
	printf("I am a student\n");
	system("pause");
	return 0;
}