#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	printf("Hello, World!\n");
	system("pause");
	return 0;
}