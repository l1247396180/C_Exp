#include<iostream>
#include<cstdio>
using namespace std;
int main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	printf("%d\n",a+b);
	system("pause");
	return 0;
}